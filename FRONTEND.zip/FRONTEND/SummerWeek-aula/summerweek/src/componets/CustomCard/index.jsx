import './style.css'

import {Button, Card} from 'react-bootstrap'

export default function CustomCard(props) {

    return (
        <Card className="custom-card">
            <span class="material-icons-outlined custom-icon" onClick={()=> props.favoriteMovie(props.movie)}>star</span>
            <Card.Img variant="top" src={props.movie.urlImg} className="custom-image" />
            <Card.Body>

                <Card.Title>{props.movie.titulo}</Card.Title>
                <Card.Text>
                    {props.movie.descricao}
                </Card.Text>
                <Button variant="primary" onClick={ ()=> props.openDetails(props.movie)}>Detalhes</Button>
            </Card.Body>
        </Card>
    )
}